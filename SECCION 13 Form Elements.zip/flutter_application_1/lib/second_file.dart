import 'package:flutter/material.dart';

void main() => runApp(MyClass());

class MyClass extends StatelessWidget {

  @override
  Widget build(BuildContext context) {

    return MaterialApp(
      debugShowCheckedModeBanner: false,

      home: Scaffold(

        appBar: AppBar(
          title: Text('Flexible and Expanded Widgets'),
          centerTitle: true,
        ),

        body: Column(

          children: [

            // ROW 1 -> EXPANDED

            Row(

              children: [

                Expanded(
                  flex: 1,

                  child: Container(
                    height: 120,
                    color: Colors.blue,

                    child: Center(
                      child: Text(
                        'Flex 1',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                        ),
                      ),
                    ),
                  ),
                ),

                Expanded(
                  flex: 3,

                  child: Container(
                    height: 120,
                    color: Colors.red,

                    child: Center(
                      child: Text(
                        'Flex 3',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),

            SizedBox(height: 20),

            // ROW 2 -> FLEXIBLE

            Row(

              children: [

                Flexible(

                  child: Container(
                    height: 120,
                    color: Colors.green,

                    child: Center(
                      child: Text(
                        'Flexible',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                        ),
                      ),
                    ),
                  ),
                ),

                Flexible(

                  child: Container(
                    height: 120,
                    color: Colors.orange,

                    child: Center(
                      child: Text(
                        'Flexible',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}