import 'package:flutter/material.dart';

class SecondClass extends StatefulWidget {
  const SecondClass({super.key});

  @override
  State<SecondClass> createState() => _SecondClassState();
}

class _SecondClassState extends State<SecondClass> {
  
  String _maritalStatus = 'single'; 
  bool _termsChecked = true;        
  String? _selectedCity;            

  // Lista de ciudades para el menú desplegable
  final List<String> _locations = ['A', 'B', 'C', 'D'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 10.0,
        title: const Center(
          child: Text('Title'),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {},
          ),
        ],
      ),
      body: Material(
        child: SingleChildScrollView(
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 10.0),
            child: Form(
              child: Column(
                children: [
                  // 1. Campo de Texto: Nombre
                  TextFormField(
                    maxLength: 20,
                    decoration: const InputDecoration(
                      labelText: 'Enter Name',
                      hintText: 'Name',
                    ),
                  ),

                  
                  TextFormField(
                    keyboardType: TextInputType.phone, 
                    decoration: const InputDecoration(
                      hintText: 'Age',
                      labelText: 'Enter Age',
                    ),
                  ),

                  
                  TextFormField(
                    obscureText: true, // Oculta los caracteres con puntos
                    decoration: const InputDecoration(
                      hintText: 'Password',
                      labelText: 'Enter Password',
                    ),
                  ),

                  const SizedBox(height: 15),

                  
                  DropdownButton<String>(
                    hint: const Text('Please choose the city you live in'),
                    value: _selectedCity,
                    isExpanded: true, // Hace que ocupe todo el ancho disponible
                    items: _locations.map((String location) {
                      return DropdownMenuItem<String>(
                        value: location,
                        child: Text(location),
                      );
                    }).toList(),
                    onChanged: (String? newValue) {
                      setState(() {
                        _selectedCity = newValue;
                      });
                    },
                  ),

                  const SizedBox(height: 15),

                  
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Expanded(
                        child: RadioListTile<String>(
                          title: const Text('Single'),
                          value: 'single',
                          groupValue: _maritalStatus,
                          onChanged: (String? value) {
                            setState(() {
                              _maritalStatus = value!;
                            });
                          },
                        ),
                      ),
                      Expanded(
                        child: RadioListTile<String>(
                          title: const Text('Married'),
                          value: 'married',
                          groupValue: _maritalStatus,
                          onChanged: (String? value) {
                            setState(() {
                              _maritalStatus = value!;
                            });
                          },
                        ),
                      ),
                    ],
                  ),

                  
                  CheckboxListTile(
                    value: _termsChecked,
                    title: const Text('Sign up for the newspaper and related articles'),
                    onChanged: (bool? value) {
                      setState(() {
                        _termsChecked = value!;
                      });
                    },
                  ),

                  const SizedBox(height: 20),

                  // 7. Botón de Registro
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,     // Color de fondo
                      foregroundColor: Colors.white,    // Color del texto
                    ),
                    onPressed: () {
                      
                    },
                    child: const Text('Register'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}