import 'dart:math'; 
import 'package:flutter/material.dart';
import 'util.dart'; 

class SecondClass extends StatelessWidget {
  const SecondClass({super.key});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.yellow,
      child: Center(
        // Cambiamos Text por Container, ya que los Containers aceptan tamaños y decoraciones
        child: Container(
          height: 500.0,
          width: 300.0,
          alignment: Alignment.center, 
          decoration: const BoxDecoration(
            gradient: RadialGradient(
              colors: [Colors.green, Colors.blue, Colors.orange, Colors.pink],
              stops: [0.2, 0.5, 0.7, 1.1],
              center: Alignment(0.1, 0.3),
              focal: Alignment(-0.1, 0.6),
            ),
          ),
          
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                generateNumbers(),
                textDirection: TextDirection.ltr,
                style: const TextStyle(color: Colors.white, fontSize: 18),
              ),
              const SizedBox(height: 20),
             
              ElevatedButton(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('It was pressed'),
                      duration: Duration(seconds: 2),
                    ),
                  );
                },
                child: const Text('Press me'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  
  String generateNumbers() {
    var r = Random();
    int i = r.nextInt(20);
    return 'A random number between 0 and 20 is $i';
  }
}