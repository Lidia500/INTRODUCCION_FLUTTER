import 'package:flutter/material.dart';

void main() => runApp(MyClass());

class MyClass extends StatelessWidget {

  @override
  Widget build(BuildContext context) {

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(

        appBar: AppBar(
          centerTitle: true,
          elevation: 5.0,

          title: Text('My Flutter App'),

          actions: [
            Icon(Icons.settings),
          ],

          bottom: PreferredSize(
            preferredSize: Size.fromHeight(40.0),
            child: Text(
              'This is a text in AppBar',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ),

        body: Center(
          child: Text('Hello Lidia'),
        ),
      ),
    );
  }
}