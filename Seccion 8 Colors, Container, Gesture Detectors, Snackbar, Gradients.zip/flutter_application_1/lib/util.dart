import 'package:flutter/material.dart';


var colorPurple = Colors.cyan; 
const darkPurpleColor = Color(0xFF880E4F); 
const ligthPurpleColor = Colors.purple; 
const ligthPurpleColorShade300 = Color(0xFFBA68C8); 