import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {

    return MaterialApp(

      debugShowCheckedModeBanner: false,

      home: FirstScreen(),
    );
  }
}

class FirstScreen extends StatefulWidget {

  @override
  _FirstScreenState createState() => _FirstScreenState();
}

class _FirstScreenState extends State<FirstScreen> {

  final _formKey = GlobalKey<FormState>();

  String name = '';
  int age = 0;
  String password = '';
  String location = 'A';
  String maritalStatus = 'Single';
  bool termsChecked = true;

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title: Text('Flutter Form'),
      ),

      body: SingleChildScrollView(

        child: Container(

          margin: EdgeInsets.symmetric(horizontal: 20.0),

          child: Form(

            key: _formKey,

            child: Column(

              children: [

                SizedBox(height: 20),

                // NAME

                TextFormField(

                  decoration: InputDecoration(
                    labelText: 'Enter Name',
                    border: OutlineInputBorder(),
                  ),

                  validator: (value){

                    if(value == null || value.isEmpty){

                      return 'Please enter name';
                    }

                    return null;
                  },

                  onSaved: (value){

                    setState(() {

                      name = value!;
                    });
                  },
                ),

                SizedBox(height: 20),

                // AGE

                TextFormField(

                  keyboardType: TextInputType.number,

                  decoration: InputDecoration(
                    labelText: 'Enter Age',
                    border: OutlineInputBorder(),
                  ),

                  validator: (value){

                    if(value == null || value.isEmpty){

                      return 'Please enter age';
                    }

                    return null;
                  },

                  onSaved: (value){

                    setState(() {

                      age = int.parse(value!);
                    });
                  },
                ),

                SizedBox(height: 20),

                // PASSWORD

                TextFormField(

                  obscureText: true,

                  maxLength: 20,

                  decoration: InputDecoration(
                    labelText: 'Enter Password',
                    border: OutlineInputBorder(),
                  ),

                  validator: (value){

                    if(value == null || value.isEmpty){

                      return 'Please enter password';
                    }

                    if(value.length < 8){

                      return 'Password should be more than 8 characters';
                    }

                    return null;
                  },

                  onSaved: (value){

                    setState(() {

                      password = value!;
                    });
                  },
                ),

                SizedBox(height: 20),

                // DROPDOWN

                DropdownButton<String>(

                  value: location,

                  isExpanded: true,

                  items: ['A', 'B', 'C', 'D']
                      .map((String value){

                    return DropdownMenuItem<String>(

                      value: value,

                      child: Text(value),
                    );

                  }).toList(),

                  onChanged: (value){

                    setState(() {

                      location = value!;
                    });
                  },
                ),

                SizedBox(height: 20),

                // RADIO BUTTONS

                Row(

                  children: [

                    Expanded(

                      child: RadioListTile(

                        title: Text('Single'),

                        value: 'Single',

                        groupValue: maritalStatus,

                        onChanged: (value){

                          setState(() {

                            maritalStatus = value.toString();
                          });
                        },
                      ),
                    ),

                    Expanded(

                      child: RadioListTile(

                        title: Text('Married'),

                        value: 'Married',

                        groupValue: maritalStatus,

                        onChanged: (value){

                          setState(() {

                            maritalStatus = value.toString();
                          });
                        },
                      ),
                    ),
                  ],
                ),

                SizedBox(height: 20),

                // CHECKBOX

                CheckboxListTile(

                  title: Text('Accept Terms & Conditions'),

                  controlAffinity: ListTileControlAffinity.leading,

                  value: termsChecked,

                  onChanged: (value){

                    setState(() {

                      termsChecked = value!;
                    });
                  },
                ),

                SizedBox(height: 20),

                // BUTTON

                ElevatedButton(

                  onPressed: () {

                    if(_formKey.currentState!.validate()){

                      _formKey.currentState!.save();

                      print(name);
                      print(age);
                      print(password);
                      print(location);
                      print(maritalStatus);
                      print(termsChecked);

                      ScaffoldMessenger.of(context).showSnackBar(

                        SnackBar(

                          content: Text('Form Submitted Successfully'),
                        ),
                      );
                    }
                  },

                  child: Text('Register'),
                ),

                SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

