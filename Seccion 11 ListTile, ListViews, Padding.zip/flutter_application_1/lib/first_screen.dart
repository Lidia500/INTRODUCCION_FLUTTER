import 'package:flutter/material.dart';

class FirstScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(
        title: Text('ListView Example'),
      ),

      body: ListView(

        children: [

          Container(

            margin: EdgeInsets.symmetric(horizontal: 20),
            padding: EdgeInsets.all(15),

            color: Colors.green,

            child: ListTile(

              leading: Icon(Icons.pets),

              title: Text('Dog'),

              subtitle: Text('This is an animal'),

              trailing: Icon(Icons.arrow_forward),

            ),
          ),

          Container(

            margin: EdgeInsets.symmetric(horizontal: 20),
            padding: EdgeInsets.all(15),

            color: Colors.orange,

            child: ListTile(

              leading: Icon(Icons.pets),

              title: Text('Cat'),

              subtitle: Text('This is an animal'),

              trailing: Icon(Icons.arrow_forward),

            ),
          ),
        ],
      ),
    );
  }
}