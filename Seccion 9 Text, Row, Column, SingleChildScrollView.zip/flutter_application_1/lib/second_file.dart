import 'dart:math';
import 'package:flutter/material.dart';

void main() => runApp(MyClass());

class MyClass extends StatelessWidget {
  const MyClass({super.key});

  // Función para generar números aleatorios
  String generateNumbers() {
    var r = Random();
    int i = r.nextInt(20);

    return 'A random number between 0 and 20 is $i';
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,

      home: Scaffold(
        appBar: AppBar(
          title: const Text('Section 9 Flutter'),
          centerTitle: true,
          elevation: 5.0,

          // Icono en AppBar
          actions: const [
            Icon(Icons.settings),
          ],
        ),

        // Scroll para evitar overflow
        body: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,

            children: [

              // Primer Container
              Container(
                height: 300.0,
                width: 300.0,

                alignment: Alignment.center,

                decoration: const BoxDecoration(
                  gradient: RadialGradient(
                    colors: [
                      Colors.green,
                      Colors.blue,
                      Colors.orange,
                      Colors.pink,
                    ],

                    stops: [
                      0.2,
                      0.5,
                      0.7,
                      1.0,
                    ],

                    center: Alignment(0.1, 0.3),
                    focal: Alignment(-0.1, 0.6),
                  ),
                ),

                child: Text(
                  generateNumbers(),

                  textDirection: TextDirection.ltr,

                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),

              const SizedBox(height: 30),

              // Segundo Container
              Container(
                height: 200.0,
                width: 200.0,
                color: Colors.purple,

                child: const Center(
                  child: Icon(
                    Icons.favorite,
                    color: Colors.white,
                    size: 50,
                  ),
                ),
              ),

              const SizedBox(height: 30),

              // Botón
              ElevatedButton(
                onPressed: () {

                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Button Pressed'),
                      duration: Duration(seconds: 2),
                    ),
                  );

                },

                child: const Text('Press Me'),
              ),

              const SizedBox(height: 30),

            ],
          ),
        ),
      ),
    );
  }
}