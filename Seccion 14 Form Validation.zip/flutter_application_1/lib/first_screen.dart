import 'package:flutter/material.dart';

class SecondClass extends StatefulWidget {
  const SecondClass({super.key});

  @override
  State<SecondClass> createState() => _SecondClassState();
}

class _SecondClassState extends State<SecondClass> {

  // KEY DEL FORMULARIO
  final _formKey = GlobalKey<FormState>();

  String _maritalStatus = 'single';
  bool _termsChecked = true;
  String? _selectedCity;

  // Lista de ciudades
  final List<String> _locations = ['A', 'B', 'C', 'D'];

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        elevation: 10.0,

        title: const Center(
          child: Text('Title'),
        ),

        actions: [

          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {},
          ),
        ],
      ),

      body: Material(

        child: SingleChildScrollView(

          child: Container(

            margin: const EdgeInsets.symmetric(horizontal: 10.0),

            child: Form(

              key: _formKey,

              child: Column(

                children: [

                  // NAME
                  TextFormField(

                    maxLength: 20,

                    decoration: const InputDecoration(
                      labelText: 'Enter Name',
                      hintText: 'Name',
                    ),

                    validator: (value) {

                      if (value == null || value.isEmpty) {

                        return 'Please enter name';
                      }

                      return null;
                    },
                  ),

                  // AGE
                  TextFormField(

                    keyboardType: TextInputType.phone,

                    decoration: const InputDecoration(
                      hintText: 'Age',
                      labelText: 'Enter Age',
                    ),

                    validator: (value) {

                      if (value == null || value.isEmpty) {

                        return 'Enter age';
                      }

                      return null;
                    },
                  ),

                  // PASSWORD
                  TextFormField(

                    obscureText: true,

                    decoration: const InputDecoration(
                      hintText: 'Password',
                      labelText: 'Enter Password',
                    ),

                    validator: (value) {

                      if (value == null || value.isEmpty) {

                        return 'Enter password';
                      }

                      if (value.length < 8) {

                        return 'Password must be 8 characters';
                      }

                      return null;
                    },
                  ),

                  const SizedBox(height: 15),

                  // DROPDOWN
                  DropdownButton<String>(

                    hint: const Text(
                      'Please choose the city you live in',
                    ),

                    value: _selectedCity,

                    isExpanded: true,

                    items: _locations.map((String location) {

                      return DropdownMenuItem<String>(

                        value: location,

                        child: Text(location),
                      );

                    }).toList(),

                    onChanged: (String? newValue) {

                      setState(() {

                        _selectedCity = newValue;
                      });
                    },
                  ),

                  const SizedBox(height: 15),

                  // RADIO BUTTONS
                  Row(

                    mainAxisSize: MainAxisSize.min,

                    children: [

                      Expanded(

                        child: RadioListTile<String>(

                          title: const Text('Single'),

                          value: 'single',

                          groupValue: _maritalStatus,

                          onChanged: (String? value) {

                            setState(() {

                              _maritalStatus = value!;
                            });
                          },
                        ),
                      ),

                      Expanded(

                        child: RadioListTile<String>(

                          title: const Text('Married'),

                          value: 'married',

                          groupValue: _maritalStatus,

                          onChanged: (String? value) {

                            setState(() {

                              _maritalStatus = value!;
                            });
                          },
                        ),
                      ),
                    ],
                  ),

                  // CHECKBOX
                  CheckboxListTile(

                    value: _termsChecked,

                    title: const Text(
                      'Sign up for the newspaper and related articles',
                    ),

                    onChanged: (bool? value) {

                      setState(() {

                        _termsChecked = value!;
                      });
                    },
                  ),

                  const SizedBox(height: 20),

                  // BUTTON
                  ElevatedButton(

                    style: ElevatedButton.styleFrom(

                      backgroundColor: Colors.blue,

                      foregroundColor: Colors.white,
                    ),

                    onPressed: () {

                      if (_formKey.currentState!.validate()) {

                        ScaffoldMessenger.of(context).showSnackBar(

                          const SnackBar(
                            content: Text('Form Valid'),
                          ),
                        );
                      }
                    },

                    child: const Text('Register'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}